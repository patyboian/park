insert into USUARIOS (id, username, password, role) values (100, 'ana@gmail.com', '123456', 'ROLE_ADMIN');
insert into USUARIOS (id, username, password, role) values (101, 'bia@gmail.com', '123456', 'ROLE_CLIENTE');
insert into USUARIOS (id, username, password, role) values (102, 'bob@gmail.com', '123456', 'ROLE_CLIENTE');