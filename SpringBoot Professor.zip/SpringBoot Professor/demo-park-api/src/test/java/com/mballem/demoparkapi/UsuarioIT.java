package com.mballem.demoparkapi;

import com.mballem.demoparkapi.web.dto.UsuarioCreateDto;
import com.mballem.demoparkapi.web.dto.UsuarioResponseDto;
import com.mballem.demoparkapi.web.dto.UsuarioSenhaDto;
import com.mballem.demoparkapi.web.exception.ErrorMessage;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.List;

// Vamos precisar usar o Tomcat para testes, mas de forma da biblioteca de testes,
// WebEnvironment.RANDOM_PORT faz com que o Tomcat seja executado em uma porta randomica
//a anotação Sql faz com que seja importado os scripts que criamos
// parametro script é onde o arquivo foi criado
// parametro executionPhase diz qd o arquivo deve ser executado
// o insert é BEFORE_TEST_METHOD pq tem que ser criado os registros antes de começar os testes
// o delete fica como AFTER_TEST_METHOD, para qd acabar os testes tudo seja deletado
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Sql(scripts = "/sql/usuarios/usuarios-insert.sql", executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD)
@Sql(scripts = "/sql/usuarios/usuarios-delete.sql", executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
public class UsuarioIT {

    @Autowired
    WebTestClient testClient;

    // Pra testar sempre usamos a anotação Test
    @Test
    // Todos os metodos de teste são public e void
    // é recomendavel nomear os metodos da seguinte forma: motivo do teste_ o que vai ser testado_o que esperar de retorno
    // assim fica mais facil para os demais programadores entender
    // a partir do exchange() colocamos o que é esperado por nós nessa requisição
    // colocamos o isCreated() que é o código 201, se chegar outro código, essa linha do teste gera uma exceção
// expectBody é referente ao corpo da requisição que estamos esperando, e aqui vamos citar o tipo de corpo
// getResponseBody() faz com que seja retornado um usuario do tipo UsuarioResponseDTO
    public void createUsuario_ComUsernameEPasswordValidos_RetornarUsuarioCriadoComStatus201(){
        UsuarioResponseDto responseBody = testClient
                .post()
                .uri("/api/v1/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioCreateDto("tody@gmail.com", "123456"))
                .exchange()
                .expectStatus().isCreated()
                .expectBody(UsuarioResponseDto.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getId()).isNotNull(); // verifica se o metodo id tb não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getUsername()).isEqualTo("tody@gmail.com"); // verificamos se é o mesmo valor que foi retornado
        org.assertj.core.api.Assertions.assertThat(responseBody.getRole()).isEqualTo("CLIENTE");
    }

    @Test
    //Vamos testar as formas de senha errada
    public void createUsuario_ComPasswordInvalido_RetornarErrorMessageStatus422(){
        ErrorMessage responseBody = testClient
                .post()
                .uri("/api/v1/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioCreateDto("tody@gmail.com", ""))// Testando a senha nula
                .exchange()
                .expectStatus().isEqualTo(422)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(422); // conseguimos validar se o erro de retorno realmente é o 422

        responseBody = testClient
                .post()
                .uri("/api/v1/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioCreateDto("tody@gmail.com", "1234")) //Testando a senha com menos de 6 caracteres
                .exchange()
                .expectStatus().isEqualTo(422)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(422); // conseguimos validar se o erro de retorno realmente é o 422


        responseBody = testClient
                .post()
                .uri("/api/v1/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioCreateDto("tody@gmail.com", "12345678")) //Testando a senha com mais de 6 caracteres
                .exchange()
                .expectStatus().isEqualTo(422)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(422); // conseguimos validar se o erro de retorno realmente é o 422
    }

    @Test
    //Vamos testar as formas de email errado
    public void createUsuario_ComUsernameInvalidos_RetornarErrorMessageStatus422(){
        ErrorMessage responseBody = testClient
                .post()
                .uri("/api/v1/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioCreateDto("", "123456"))// Testanto email nullo
                .exchange()
                .expectStatus().isEqualTo(422)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(422); // conseguimos validar se o erro de retorno realmente é o 422

        responseBody = testClient
                .post()
                .uri("/api/v1/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioCreateDto("tody", "123456")) // Testanto email sem @...
                .exchange()
                .expectStatus().isEqualTo(422)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(422); // conseguimos validar se o erro de retorno realmente é o 422


        responseBody = testClient
                .post()
                .uri("/api/v1/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioCreateDto("tody@gmail.", "123456")) // Testanto email sem .com
                .exchange()
                .expectStatus().isEqualTo(422)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(422); // conseguimos validar se o erro de retorno realmente é o 422
    }

    @Test
    public void createUsuario_ComUsernameRepetido_RetornarErrorMessageComStatus409(){
        ErrorMessage responseBody = testClient
                .post()
                .uri("/api/v1/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioCreateDto("ana@gmail.com", "123456"))//Tentando cadastrar um e-mail que já existe
                .exchange()
                .expectStatus().isEqualTo(409)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(409); // se o erro for 409 está ok

    }

    @Test
    public void buscarUsuario_ComIdExistente_RetornarUsuarioComStatus200(){
        UsuarioResponseDto responseBody = testClient
                .get()//colocamos get pq vamos buscar
                .uri("/api/v1/usuarios/100") // vamos buscar o id 100
                .exchange()
                .expectStatus().isOk() // status 200
                .expectBody(UsuarioResponseDto.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getId()).isEqualTo(100); // verifica se o metodo id tb não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getUsername()).isEqualTo("ana@gmail.com"); // verificamos se é o mesmo valor que foi retornado
        org.assertj.core.api.Assertions.assertThat(responseBody.getRole()).isEqualTo("ADMIN");
    }

    @Test
    public void buscarUsuario_ComIdInexistente_RetornarErrorMessageComStatus404(){
        ErrorMessage responseBody = testClient
                .get()//colocamos get pq vamos buscar
                .uri("/api/v1/usuarios/0") //
                .exchange()
                .expectStatus().isNotFound() // status 404
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(404);

    }

@Test
public void editarSenha_ComDadosValidos_RetornarStatus204(){
            testClient
            .patch()
            .uri("/api/v1/usuarios/100")
            .contentType(MediaType.APPLICATION_JSON)
            .bodyValue(new UsuarioSenhaDto("123456", "123456","123456"))
            .exchange()
            .expectStatus().isNoContent();

    //Como não tem retorno, não precisamos passar os testes
    }

    @Test
    public void editarSenha_ComIdInexistente_RetornarErrorMessageComStatus404(){
        ErrorMessage responseBody = testClient
                .patch()//colocamos get pq vamos buscar
                .uri("/api/v1/usuarios/0") //testando id inexistente
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioSenhaDto("123456", "123456","123456"))
                .exchange()
                .expectStatus().isNotFound() // status 404
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(404);

    }

    @Test
    public void editarSenha_ComCamposInvalidos_RetornarErrorMessageComStatus422(){
        ErrorMessage responseBody = testClient
                .patch()//colocamos get pq vamos buscar
                .uri("/api/v1/usuarios/100")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioSenhaDto("", "",""))
                .exchange()
                .expectStatus().isEqualTo(422)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(422);

        responseBody = testClient
        .patch()//colocamos get pq vamos buscar
                .uri("/api/v1/usuarios/100")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioSenhaDto("12345", "12345","12345"))
                .exchange()
                .expectStatus().isEqualTo(422)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(422);

        responseBody = testClient
                .patch()//colocamos get pq vamos buscar
                .uri("/api/v1/usuarios/100")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioSenhaDto("12345678", "12345678","12345678"))
                .exchange()
                .expectStatus().isEqualTo(422)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(422);

    }

    @Test
    public void editarSenha_ComSenhasInvalidos_RetornarErrorMessageComStatus400(){
        ErrorMessage responseBody = testClient
                .patch()//colocamos get pq vamos buscar
                .uri("/api/v1/usuarios/100")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioSenhaDto("123456", "123456","000000"))
                .exchange()
                .expectStatus().isEqualTo(400)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(400);

        responseBody = testClient
                .patch()//colocamos get pq vamos buscar
                .uri("/api/v1/usuarios/100")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new UsuarioSenhaDto("123457", "123456","123456"))
                .exchange()
                .expectStatus().isEqualTo(400)
                .expectBody(ErrorMessage.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.getStatus()).isEqualTo(400);
    }

    @Test
    public void ListarUsuarios_SemQualquerParametro_RetornarListaDeUsuariosComStatus200(){
         List<UsuarioResponseDto> responseBody=  testClient
                .get()//colocamos get pq vamos buscar
                .uri("/api/v1/usuarios")
                .exchange()
                .expectStatus().isOk() // status 200
                .expectBodyList(UsuarioResponseDto.class)
                .returnResult().getResponseBody();

        // Daqui pra baixo vamos usar uma classe para verificar o objeto retornado pela requisição
// a classe  org.assertj.core.api.Assertions me da acesso aos metodos que irão testar o objeto
        org.assertj.core.api.Assertions.assertThat(responseBody).isNotNull(); // verificamos se o retorno não é nulo
        org.assertj.core.api.Assertions.assertThat(responseBody.size()).isEqualTo(3); // confirma se tem apenas 3 usuarios cadastrados
        }
}
// Na Classe Controller, temos 3 tipos de erros cadastrados, então temos que validar os 3
// Podemos executar cada metodo individualmente, clicanco na seta verde que aparece ao lado de cada metodo