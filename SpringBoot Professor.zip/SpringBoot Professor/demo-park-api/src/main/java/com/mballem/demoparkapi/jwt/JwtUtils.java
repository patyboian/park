package com.mballem.demoparkapi.jwt;
// Classe responsável por gerar o token

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

@Slf4j // imprimir o log no console caso haja exceção


public class JwtUtils {
    public static final String JWT_BEARER = "Bearer ";
    public static final String JWT_AUTHORIZATION = "Autorization";
    public static final String SECRET_KEY = "0123456789-0123456789-0123456789"; // PRECISA TER 32 CARACTERES MAS PODEMOS COLOCAR O QUE QUISER
    // PRECISA DE 32 CARACTERES PQ O PROCESSO QUE VAI FAZER A CRIPTOGRAFIA DA CHAVE, PRECISA TER NO MINIMO 32 CARACTERES
    // as variaveis abaixo são para definir o tempo de expiração do token
    // Neste caso, vai expirar depois de 2 minutos (rapido apenas para teste, depois podemos aumentar)
    public static final long EXPIRE_DAYS = 0;
    public static final long EXPIRE_HOURS = 0;
    public static final long EXPIRE_MINUTES = 2;

    private JwtUtils(){

    }
// hmacShaKeyFor prepara a nossa chave para ser criptografada no momento em que for gerar o token
    private static Key generateKey(){
        return Keys.hmacShaKeyFor(SECRET_KEY.getBytes(StandardCharsets.UTF_8));
    }
// metodo referente à expiração do token, calculo entre a data que o token foi criado e a data que queremos que ele expire
    // com atZone já verificamos se está de acordo com o timezone que configuramos na aplicação
    // usando os metodos plus, ele vai somar os atributos definidos na declação acima, à variavel start
    private static Date toExpireDate(Date start){
        LocalDateTime dateTime = start.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        LocalDateTime end = dateTime.plusDays(EXPIRE_DAYS).plusHours(EXPIRE_HOURS).plusMinutes(EXPIRE_MINUTES);
        return Date.from(end.atZone(ZoneId.systemDefault()).toInstant());
    }

    // metodo que vai gerar o token

    public static JwtToken createToken(String username, String role){
        Date issuedAt = new Date(); // assim estamos definindo a data de criação do token
        Date linit = toExpireDate(issuedAt); //data limite do token

        // Iremos retornar o token gerado
        String token = Jwts.builder()
                .setHeaderParam("typ","JWT") // informa que é um token do tipo JWT
                .setSubject(username) // sempre bom ter o id ou username, para validar se é de um usuario existente
                .setIssuedAt(issuedAt) // recebe a data de geração do token
                .setExpiration(linit) // recebe a data de expiração do token
                .signWith(generateKey(), SignatureAlgorithm.HS256)
                .claim("role", role) // qd queremos incluir alguma informação no token, mas não tem um metodo pra isso, por exemplo perfil do usuario
                .compact(); // transforma o obj em um token no formato string, que tenha o padrão aa base64, separado cada parte por ponto

        return new JwtToken(token);
    }

    // metodo para recuperar o conteudo do token

    private static Claims getClaimsFromToken(String token){
        try {
            return Jwts.parserBuilder() // passamos o generateKey pq a partir da chave que a gente tem, ele vai verificar se a assinatura que recebemos é a mesma que esta gerada aqui
                    .setSigningKey(generateKey()).build()
                    .parseClaimsJws(refactorToken(token)).getBody(); // pra recuperar o corpo do cabeçalho, mas pre isso precisamos tirar o bearer, o que fizemos o no metodo abaixo
        } catch (JwtException ex){
            log.error(String.format("Token inválido %s", ex.getMessage()));
        }
        return null; // se a instrução não retornar nenhuma excessão, retornaremos o corpo do token
    }

    // metodo para recuperar o username que está dentro do token

    public static String getUsernameFromToken(String token){
        // o getClaimsFromToken vai retornar o corpo do token
        return getClaimsFromToken(token).getSubject();
    }

    // metodo para testar a validade do token
    public static boolean isTokenValid(String token){
        try {
            Jwts.parserBuilder() // passamos o generateKey pq a partir da chave que a gente tem, ele vai verificar se a assinatura que recebemos é a mesma que esta gerada aqui
                    .setSigningKey(generateKey()).build()
                    .parseClaimsJws(refactorToken(token));
            return true;
        } catch (JwtException ex){
            log.error(String.format("Token inválido %s", ex.getMessage())); //pode ser invalido pq a data do token expirou po pq a assinatura não confere
        }
        return false;
    }

// Metodo para tirar o bearer do token
    private static String refactorToken(String token){
        if (token.contains(JWT_BEARER)){
            return token.substring(JWT_BEARER.length());
        }
        return token;
    }
}
