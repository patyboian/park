package com.mballem.demoparkapi.web.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class UsuarioCreateDto {
// Só a anotação Email já valida o formato do email que podemos aceitar, caso a gente não ache
    // ela completa, na frente podemos usar o (regexp = ), colocando a expressão que queremos validar
    // O campo msg é a msg que vai aparecer para o cliente, não é obrigatoria, pois a anotação ja manda msg
    // Com o regexp ficaria: (regexp = "", message = "formato do email invalido.")
   // o "Email aceita qualquer coisa depois do @, não precisando ter o .com, o que precisa ser tratado
    // Sempre devemos ler a documentação, neste caso o @email aceita valor nulo
// Not null valida se nulo, not empty valida se estiver vazio ou nullo, not blank se estiver vazio
// regexp = "^[a-z0-9.+-]+@[a-z0-9.-]+\\.[a-z]{2,}$ significa: antes do @ dever ter uma qtd ilimitada (^) de letras, ou numeros ou pontos
    // Se quiser que tenha # ou % tem que ser colocado na validação junto com o +-
    // depois do arrova ou letras, ou numeros, ou ponto ou traço
    // depois desses caracteres tem que ter um .
    // depois do . tem que ter letras e no minimo 2
    @NotBlank
    @Email(message = "formato do email invalido.", regexp = "^[a-z0-9.+-]+@[a-z0-9.-]+\\.[a-z]{2,}$")
    private String username;

    @NotBlank
    // De acordo com nossa documentação, nossa senha vai ter no minimo6 e no maximo 6 caracteres
    @Size(min = 6, max= 6)
    private String password;
}
