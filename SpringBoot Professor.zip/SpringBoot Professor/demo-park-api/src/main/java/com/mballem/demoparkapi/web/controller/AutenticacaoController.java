package com.mballem.demoparkapi.web.controller;
// é nessa classe que vai receber o processo de autenticação, é a partir dessa classe que o usuario vai
// enviar o login e a senha dele pra tentar autenticar na app e se tiver sucesso vamos gerar o token

import com.mballem.demoparkapi.jwt.JwtToken;
import com.mballem.demoparkapi.jwt.JwtUserDetailsService;
import com.mballem.demoparkapi.web.dto.UsuarioLoginDTO;
import com.mballem.demoparkapi.web.exception.ErrorMessage;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RequestMapping ("/api/v1")
@RestController
@RequiredArgsConstructor
@Slf4j

public class AutenticacaoController {

    private final JwtUserDetailsService detailsService;
    private final AuthenticationManager authenticationManager;

    @PostMapping("/auth") // /api/v1/auth acessamos o recurso para autenticar
    // Descrição
    // O usuário vai enviar uma solicitação contendo username e password, vamos recuperar os 2 valores
    // e passar para a classe UsernamePasswordAuthenticationToken
    // essa classe vai pegar o usuario e senha e buscar no banco de dados pra ver se existe
    // se ok, retorna o token e add o objeto como parte do contexto de autentição do spring pelo metodo autenticate
    // se o metodo gerar exceção, vamos cair no catch e no Badrequest
    // Se passar por isso sem execção, vamos gerar o token no JwtToken token = detailsService.getTokenAthenticate(dto.getUsername());


    public ResponseEntity<?> autenticar(@RequestBody @Valid UsuarioLoginDTO dto, HttpServletRequest request){
        log.info("Processo de autenticação pelo login {}", dto.getUsername()); // não é obrigado, é apenas para ver que a requisição chegou nesse metodo com o username
// vamos colocar um try catch, pq se ele conseguir logar, vamos retornar o token, mas se ele não
        // conseguir, vai ser lançado uma exceção e depois vamos lançar um Bad Request como resposta
        try {
            UsernamePasswordAuthenticationToken authenticationToken =
                    new UsernamePasswordAuthenticationToken(dto.getUsername(), dto.getPassword());


            authenticationManager.authenticate(authenticationToken);


            JwtToken token = detailsService.getTokenAthenticated(dto.getUsername());


            return ResponseEntity.ok(token);
// iremos utilizar a AuthenticationException do pacote security score
        } catch (AuthenticationException ex) {
            log.warn("Bad Credentials from username '{}'", dto.getUsername());
        }
        return ResponseEntity
                .badRequest()
                .body(new ErrorMessage(request, HttpStatus.BAD_REQUEST,"Credenciais inválidas"));
    }
}
