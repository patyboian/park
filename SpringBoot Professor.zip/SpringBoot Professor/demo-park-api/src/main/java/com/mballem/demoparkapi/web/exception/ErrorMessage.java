package com.mballem.demoparkapi.web.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.servlet.http.HttpServletRequest;
import lombok.Getter;
import lombok.ToString;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

import java.util.HashMap;
import java.util.Map;

@Getter // criar os get e setters
@ToString // se em algum momento precisar visualizar o objeto de erro usamos o tostring

// independente se o projeto pedir ou não, sempre precisamos fazer isso
public class ErrorMessage {

    private String path; // vai mostrar qual recurso gerou essa exceção

    private String method; // vai mostrar qual metodo usado gerou essa exceção

    private int status; // vai representar o codigo do HTTP status

    private String statusText; // o texto do erro

    private String message; // msg do erro

    @JsonInclude (JsonInclude.Include.NON_NULL)
    // Essa anotação possui uma propriedade not null, faz vai ver qd for transformado em Json, ela vai ver se o resultado
    // é nullo , dessa forma não vai colocar la dentro do obj Json, pq é pra incluir apenas se o campo não for nulo
    private Map<String, String> errors;

    public ErrorMessage() {

    }

    public ErrorMessage(HttpServletRequest request, HttpStatus status, String message) {
        this.path = request.getRequestURI();
        this.method = request.getMethod();
        this.status = status.value(); // retorna o número do erro
        this.statusText = status.getReasonPhrase();// retorna a msg do erro
        this.message = message;
    }
//BindingResult é onde temos acesso aos erros qd eles são gerados por uma validação de campos
    public ErrorMessage(HttpServletRequest request, HttpStatus status, String message, BindingResult result) {
        this.path = request.getRequestURI();
        this.method = request.getMethod();
        this.status = status.value(); // retorna o número do erro
        this.statusText = status.getReasonPhrase();// retorna a msg do erro
        this.message = message;
        addErrors(result);
    }

    private void addErrors(BindingResult result) {
    this.errors = new HashMap<>();
    // tem que conter o nome do campo, e o valor vai ser a msg do erro
        for(FieldError fieldError : result.getFieldErrors()){
            // put onde vamos passar a chave e o valor
            // a chave pego fieldError.getField()
            // msg pego no fieldError.getDefaultMessage()
            this.errors.put(fieldError.getField(), fieldError.getDefaultMessage());
        }
    }
}
