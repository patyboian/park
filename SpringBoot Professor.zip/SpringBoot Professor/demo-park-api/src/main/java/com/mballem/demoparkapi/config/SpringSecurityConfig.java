package com.mballem.demoparkapi.config;

import com.mballem.demoparkapi.jwt.JwtAuthorizationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

// Configuration define a classe como uma classe de configuração
@Configuration
@EnableWebMvc
@EnableMethodSecurity

public class SpringSecurityConfig {
// Como estamos trabalhando com a API REST precisamos desativar alguns recursos do Spring Security, pq por
    // padrão trabalham com o tipo stateful e não stateless
    // Pra fazer o login, as pags de login do spring precisam de um token de validação, o CSRF, se não desabilitar ele
    // nunca vamos conseguir o login em uma pagina stateless
// o metodo requestMatchers é onde definimos permissões de acesso, pra isso, na nossa classe Controller, precisamos analisar
    // quais os metodos irão precisar de autenticação, no nosso caso, o unico metodo que NÃO precisa de autenticação é o create
    // mas neste metodo, ele usa a URI "api/v1/usuarios", onde ela tb é usada para acessar o metodo que listam todos os usuarios
    // como os 2 metodos usam a msm URI, algo vai precisar diferenciar os metodos, a diferença é o method htto, que um é POST e o outro é GET
// usamos o requestMatchers(HttpMethod.POST, "api/v1/usuarios").permitAll() assim qualquer usario tem acesso a URI que pode se cadastrar
   // o .anyRequest().authenticated() diz que todas os outros metodos irão precisar de autenticação
// sessionManagement define o tipo de gerenciamento de sessão
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(csrf -> csrf.disable())
                .formLogin(form -> form.disable())
                .httpBasic(basic -> basic.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(HttpMethod.POST, "api/v1/usuarios").permitAll()
                        .requestMatchers(HttpMethod.POST, "api/v1/auth").permitAll() // vamos deixar a uri public, pois usamos ea na classe autenticação controller
                        .anyRequest().authenticated()
                ).sessionManagement(
                        session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                ).addFilterBefore(
                        jwtAuthorizationFilter(), UsernamePasswordAuthenticationFilter.class
                ).build();

    }
// Precisamos registrar o filtro que criamos na classe JwtAuthorizationFilter
    // para isso temos que colocar o @BEan, esse Bean vai colocar o filtro sobre o gerenciamento do Spring

    @Bean
    public JwtAuthorizationFilter jwtAuthorizationFilter(){
        return new JwtAuthorizationFilter();
        // depois disso temos que registrar o filtro no metodo Filterchain acima, com o addFilterBefore
    }

// Novo bean que será referente ao tipo de criptografia de senha
    // BCrypt é considerada a criptografia mais segura
    @Bean
    public PasswordEncoder passwordEncoder (){
        return new BCryptPasswordEncoder();
    }


    // Referente ao gerenciamento de autenticação
    // o metodo getAuthenticationManager retorna um objeto de gerenciamento de autenticação
    @Bean
    public AuthenticationManager authenticationManager (AuthenticationConfiguration authenticationConfiguration) throws Exception {
return authenticationConfiguration.getAuthenticationManager();
    }
}
