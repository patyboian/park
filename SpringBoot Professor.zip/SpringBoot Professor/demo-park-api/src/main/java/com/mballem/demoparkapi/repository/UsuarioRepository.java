package com.mballem.demoparkapi.repository;

import com.mballem.demoparkapi.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional <Usuario> findByUsername(String username);
// Não vamos poder usar a consulta por palavra chave, pq o Spring vai lançar uma exceção, pq como o Role é um
    //Enum ele interpreta como um array, portanto, para contornar isso vamos usar o jpql, ficando com
    // a anotação @Query("select u.role from usuario u where u.username like :username") , onde o script é o jpql
    @Query("select role from usuarios where username like :username")

    Usuario.Role findRoleByUsername(String username);

}