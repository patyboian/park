package com.mballem.demoparkapi.web.exception;

import com.mballem.demoparkapi.exception.EntityNotFoundException;
import com.mballem.demoparkapi.exception.PasswordInvalidException;
import com.mballem.demoparkapi.exception.UsernameUniqueViolationException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
// @RestControllerAdvice Funciona com ouvinte, vamos registrar as exceções nessa classe, qd a API identificar algum
// Erro, ele já virá para cá para tratar
@RestControllerAdvice

public class ApiExceptionHandler {

    // Dentro de ExceptionHandler colocamos a classe que pegamos no erro do Postman
    // Exceção para qd não possuuir cadastro na busca
    @ExceptionHandler(EntityNotFoundException.class) // É a anotação que vai registrar a execção que a classe vai capturar
    public ResponseEntity<ErrorMessage> entityNotFoundException (RuntimeException ex,
                                                                         HttpServletRequest request){
        log.error("Api Error - ", ex); // Assim conseguimos ver onde a execção estourou
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND) // É O CODIGO 404
                .contentType(MediaType.APPLICATION_JSON)
                .body(new ErrorMessage(request,HttpStatus.NOT_FOUND,  ex.getMessage() )); // PEGAMOS A MSG QUE DIGITAMOS NA CLASSE
                // UNPROCESSABLE_ENTITY é o codigo do erro de qd a aplicação não consegue processar o que foi enviado pelo cliente

    }
    @ExceptionHandler(UsernameUniqueViolationException.class) // É a anotação que vai registrar a execção que a classe vai capturar
    public ResponseEntity<ErrorMessage> uniqueViolationException (RuntimeException ex,
                                                                         HttpServletRequest request){
        log.error("Api Error - ", ex); // Assim conseguimos ver onde a execção estourou
        return ResponseEntity
                .status(HttpStatus.CONFLICT) // É O CODIGO 409 DE CONFLITO DE INFORMAÇÕES
                .contentType(MediaType.APPLICATION_JSON)
                .body(new ErrorMessage(request,HttpStatus.CONFLICT,  ex.getMessage() ));
        // UNPROCESSABLE_ENTITY é o codigo do erro de qd a aplicação não consegue processar o que foi enviado pelo cliente

    }

    @ExceptionHandler(MethodArgumentNotValidException.class) // É a anotação que vai registrar a execção que a classe vai capturar
    public ResponseEntity<ErrorMessage> methodArgumentNotValidException (MethodArgumentNotValidException ex,
                                                                         HttpServletRequest request,
                                                                         BindingResult result){
        log.error("Api Error - ", ex); // Assim conseguimos ver onde a execção estourou
        return ResponseEntity
                .status(HttpStatus.UNPROCESSABLE_ENTITY)
                .contentType(MediaType.APPLICATION_JSON)
                .body(new ErrorMessage(request,HttpStatus.UNPROCESSABLE_ENTITY,  "Campo(s) invalidos", result ));
        // UNPROCESSABLE_ENTITY é o codigo do erro de qd a aplicação não consegue processar o que foi enviado pelo cliente

    }
    @ExceptionHandler(PasswordInvalidException.class) // É a anotação que vai registrar a execção que a classe vai capturar
    public ResponseEntity<ErrorMessage> passwordInvalidException (RuntimeException ex,
                                                                  HttpServletRequest request){
        log.error("Api Error - ", ex); // Assim conseguimos ver onde a execção estourou
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST) // É O CODIGO 400
                .contentType(MediaType.APPLICATION_JSON)
                .body(new ErrorMessage(request,HttpStatus.BAD_REQUEST,  ex.getMessage() ));

    }
}
