package com.mballem.demoparkapi.service;

import com.mballem.demoparkapi.entity.Usuario;
import com.mballem.demoparkapi.exception.EntityNotFoundException;
import com.mballem.demoparkapi.exception.PasswordInvalidException;
import com.mballem.demoparkapi.exception.UsernameUniqueViolationException;
import com.mballem.demoparkapi.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@RequiredArgsConstructor
@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    // a variavel abaixo será para salvar a senha criptografada
    private final PasswordEncoder passwordEncoder;

    @Transactional
    public Usuario salvar(Usuario usuario) {
// Aqui o catch vai capturar a exceçao para qd for inserir dado duplicado na tabela
        try {
            // no caso abaixo, passamos a senha digitada pelo usuario e o metodo encoder ira realizar a criptografia
           // retornando a senha criptografada para o setPassword de usuario

            usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
            return usuarioRepository.save(usuario);
        }catch (org.springframework.dao.DataIntegrityViolationException ex) {
            // Alem de capturar a exceçao, agora vamos tratar
            throw  new UsernameUniqueViolationException(String.format("Username {%s} já cadastrado", usuario.getUsername()));
//String.format é parecido com printf, o %s vai trazer o nome do usuario
        }
    }


    // Estaremos criando uma exceção para qd o cliente não existir
    @Transactional(readOnly = true) // indica ao Spring esse método é exclusivo para consulta no BD
    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id).orElseThrow( // retorna um usuário ou lança uma exceção
                () -> new EntityNotFoundException(String.format("Usuário id=%s não encontrado.",id))
                // Usamos o string format para imprimir qual o id não foi encontrado
        );
    }


    @Transactional
    public Usuario editarSenha(Long id, String senhaAtual, String novaSenha, String confirmaSenha) {
        // Vamos confirmar se a novaSenha é igual a confirmaSenha
        // para confirmar se a senha é igual, utilizariamos o !novaSenha.equals(confirmaSenha porém agora

        if(!novaSenha.equals(confirmaSenha)){ // Vamos confirmar se são diferentes, por isso o !
            // Se for diferente vamos lançar uma exceção
            throw  new PasswordInvalidException("Nova senha não confere com confirmação de senha.");
            // antes throw  new RuntimeException("Nova senha não confere com confirmação de senha.");
        }
        // Se passar pelo IF é porque está igual, então vamos fazer a busca pelo id para conferir a senha
        Usuario user = buscarPorId(id);
        // Agora vamos conferir se a senha atual é a mesma que está no banco de dados atual

        // para confirmar se a senha é igual, utilizariamos o !novaSenha.equals(confirmaSenha porém agora
        // a senha no banco para comparação está criptografada, entao usamos o matches, onde nele passamos
        // primeiro a senha crua digitada pelo usuario, segundo a senha criptografada que está no banco,

        if(!passwordEncoder.matches(senhaAtual, user.getPassword())){
            throw  new PasswordInvalidException("Sua senha não confere.");
            //Antes throw  new RuntimeException("Sua senha não confere.");
        }
        user.setPassword(passwordEncoder.encode(novaSenha));
        return user;
    }




    @Transactional(readOnly = true) // readonly true pra indicar que é apenas para consulta
    public List<Usuario> buscarTodos() {
        return usuarioRepository.findAll();
    }


    @Transactional(readOnly = true)
    public Usuario buscarPorUsername(String username) {
        return usuarioRepository.findByUsername(username).orElseThrow( // retorna um usuário ou lança uma exceção
                () -> new EntityNotFoundException(String.format("Usuário com %s não encontrado.",username))
                // Usamos o string format para imprimir qual o id não foi encontrado
        );
    }

    @Transactional(readOnly = true)
    public Usuario.Role buscarRolePorUsername(String username) {
        return usuarioRepository.findRoleByUsername(username);
    }
}
