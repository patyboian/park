package com.mballem.demoparkapi.web.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class UsuarioLoginDTO {

    @NotBlank
    @Email(message = "formato do email invalido.", regexp = "^[a-z0-9.+-]+@[a-z0-9.-]+\\.[a-z]{2,}$")
    private String username;

    @NotBlank
    // De acordo com nossa documentação, nossa senha vai ter no minimo6 e no maximo 6 caracteres
    @Size(min = 6, max= 6)
    private String password;

}
