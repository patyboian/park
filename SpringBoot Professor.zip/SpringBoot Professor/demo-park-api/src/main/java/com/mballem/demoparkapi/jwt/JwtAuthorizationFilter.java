package com.mballem.demoparkapi.jwt;
// Vamos desenvolver um filtro para capturar o token qd for enviado na requisição pelo usuario
//Por exemplo pra alterar a senha: Pra isso ele precisa estar autenticado, ele vai enviar uma requisição
//para o metodo autenticar para receber um token como resposta, ao receber o token, ele coloca o token no
//cabeçalho da requisição que vai ser enviado ao metodo do update senha, la de usuario controller,
//nosso filtro vai capturar todas as requisições que são enviadas para a API, e verificar se nelas contem um
//token, se sim, ele vai capturar o token, vamos valida-lo e autentica-lo na app com as informações contidas no token.
//caso seja invalido, o Spring interrompe a operação e envia um erro para o cliente


import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Slf4j
public class JwtAuthorizationFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUserDetailsService detailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        final String token = request.getHeader(JwtUtils.JWT_AUTHORIZATION);
        // vamos verificar se o token é nulo, o || é ou
// startsWith testa a parte inicial de uma string
        if(token == null || !token.startsWith(JwtUtils.JWT_BEARER)){
            log.info("JWT Token está nulo, vazio ou não iniciado com 'Bearer '.");// informaçao no console
        filterChain.doFilter(request, response);
        return;
        }
        // vamos testar agora se o valor retornado do metodo é falso
        if(!JwtUtils.isTokenValid(token)){
            log.warn("JWT Token está inválido ou expirado.");// informaçao no console
            filterChain.doFilter(request, response);
            return;
        }
// se tudo estiver certo, vamos pegar o username com o getUsernameFromToken
        String username = JwtUtils.getUsernameFromToken(token);

        // com o token válido, vamos autenticar
        toAuthentication(request, username);

        // se chegar nessa linha, quer dizer que o Spring finalizou
        filterChain.doFilter(request, response);
    }

    private void toAuthentication(HttpServletRequest request, String username) {
        UserDetails userDetails = detailsService.loadUserByUsername(username);
// caso o username seja localizado, o Spring vai pegar a senha do usuario e testar com a senha do Spring Security
        // e ver se ele existe, se existir vamos para o proximo passo

        UsernamePasswordAuthenticationToken authenticationToken = UsernamePasswordAuthenticationToken
                .authenticated(userDetails, null, userDetails.getAuthorities());

        // estamos passando o obj de requsição (request) para a parte de autenticação do Spring
        // assim ele consegue unir a parte de segurança com a informações da requisção
        authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

        SecurityContextHolder.getContext().setAuthentication(authenticationToken);
    }
}
